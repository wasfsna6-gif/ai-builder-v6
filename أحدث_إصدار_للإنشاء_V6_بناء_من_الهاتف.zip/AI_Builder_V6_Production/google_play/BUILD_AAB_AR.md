# بناء AAB

المشروع لا يحتوي على Gradle Wrapper في هذه الحزمة، لذلك استخدم Android Studio.

1. افتح مجلد AI_Builder_V6_Production في Android Studio.
2. ثبّت Android SDK 36 وBuild Tools المطلوبة.
3. انتظر Gradle Sync.
4. اختر Build > Generate Signed Bundle / APK.
5. اختر Android App Bundle.
6. أنشئ أو اختر Upload Key خاص بك.
7. اختر build variant = release.
8. أنشئ app-release.aab.
9. ارفع الملف إلى Play Console.

لا تشارك ملف keystore أو كلمة مروره.
