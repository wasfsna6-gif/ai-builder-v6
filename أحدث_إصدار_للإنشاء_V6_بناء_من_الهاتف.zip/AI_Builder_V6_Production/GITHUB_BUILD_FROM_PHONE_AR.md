# بناء AAB من الهاتف عبر GitHub

## الطريقة
1. أنشئ حساب GitHub أو سجّل الدخول من الهاتف.
2. أنشئ Repository جديدًا، مثل: `ai-builder-v6`.
3. ارفع محتويات هذا المشروع إلى المستودع، مع مجلد `.github/workflows`.
4. افتح تبويب Actions.
5. اختر `Build Android AAB`.
6. اضغط `Run workflow`.
7. بعد نجاح البناء افتح نتيجة التشغيل.
8. من قسم Artifacts نزّل:
   `ai-builder-v6-release-aab`
9. فك الضغط في الهاتف وستجد:
   `app-release.aab`

## ملاحظة مهمة عن التوقيع
هذا Workflow يبني AAB غير موقّع لتسهيل البناء من الهاتف.
للنشر الفعلي في Google Play يجب إعداد Upload Key/Play App Signing.

يمكن لاحقًا إضافة توقيع Release إلى GitHub Actions باستخدام GitHub Secrets، لكن لا تضع keystore أو كلمة المرور داخل المستودع.

## إذا كان GitHub يرفض الملفات
ارفع الملفات على دفعات من متصفح GitHub أو استخدم تطبيق GitHub إن كان متاحًا.
