const features=["تسجيل دخول وحسابات","واجهة رئيسية","بحث وتصنيفات","إدارة المحتوى","إشعارات","إعدادات المستخدم","لوحة تحكم","قاعدة بيانات","واجهة API","اختبارات أولية"];
const $=id=>document.getElementById(id);
function render(idea,type){
  const label={android:"تطبيق Android",web:"موقع ويب",store:"متجر إلكتروني",dashboard:"لوحة تحكم"}[type]||type;
  $("result").innerHTML=`<h3>${escapeHtml(idea)}</h3><p>نوع المشروع: ${label}</p>`+features.map(x=>`<div class="feature">✓ ${x}</div>`).join("");
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&#39;",""":"&quot;"}[m]||m))}
$("buildBtn").onclick=async()=>{
  const idea=$("idea").value.trim(); if(!idea){alert("اكتب فكرة المشروع أولاً");return}
  const type=$("type").value; localStorage.setItem("lastIdea",idea); localStorage.setItem("projectType",type);
  render(idea,type);
  $("buildBtn").textContent="✓ تم الإنشاء";
  setTimeout(()=>$("buildBtn").textContent="✦ إنشاء المشروع",900);
  const api=localStorage.getItem("apiUrl");
  if(api){
    try{
      const r=await fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idea,type})});
      if(r.ok){const data=await r.json(); if(data?.features?.length) $("result").innerHTML=`<h3>${escapeHtml(idea)}</h3>`+data.features.map(x=>`<div class="feature">✓ ${escapeHtml(String(x))}</div>`).join("")}
    }catch(e){}
  }
};
$("saveApi").onclick=()=>{localStorage.setItem("apiUrl",$("apiUrl").value.trim());alert("تم حفظ رابط Backend على الجهاز")};
window.onload=()=>{const i=localStorage.getItem("lastIdea");const u=localStorage.getItem("apiUrl");if(i)$("idea").value=i;if(u)$("apiUrl").value=u};
