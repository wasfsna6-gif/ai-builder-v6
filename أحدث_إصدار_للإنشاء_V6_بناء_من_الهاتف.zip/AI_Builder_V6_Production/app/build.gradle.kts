plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aibuilder.studio"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.aibuilder.studio"
        minSdk = 23
        targetSdk = 36
        versionCode = 6
        versionName = "6.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
