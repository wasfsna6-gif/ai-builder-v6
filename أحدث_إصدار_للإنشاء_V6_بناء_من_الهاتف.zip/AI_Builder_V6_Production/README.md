# أحدث إصدار للإنشاء V6 — Production Starter

نسخة V6 محسنة من مشروع Android السابق.

## Android
- Kotlin + Gradle
- compileSdk 36
- targetSdk 36
- minSdk 23
- applicationId: com.aibuilder.studio
- versionName: 6.0.0
- versionCode: 6

## المكونات
- واجهة عربية حديثة داخل WebView محلي.
- حفظ الفكرة محليًا.
- نقطة اتصال اختيارية لـ Backend.
- Backend Node.js منفصل كبداية آمنة.
- ملفات سياسة الخصوصية وقائمة تجهيز Play Store.

## ملاحظة
لا تزال خدمات الحسابات، قاعدة البيانات، الذكاء الاصطناعي المدفوع، والدفع بحاجة إلى ربط مزود فعلي واختبارات إنتاجية. الحزمة لا تحتوي على مفتاح API.
