# AI Builder V6 Backend

هذا خادم ابتدائي آمن لربط تطبيق Android بخدمة ذكاء اصطناعي.

## تشغيل
1. ثبّت Node.js.
2. نفّذ `npm install`.
3. انسخ `.env.example` إلى `.env`.
4. ضع مفتاح مزود الذكاء الاصطناعي في متغير البيئة فقط.
5. نفّذ `npm start`.

## مهم
لا تضع AI_API_KEY داخل تطبيق Android أو ملفات JavaScript التي تصل للمستخدم.
