require("dotenv").config();
const express=require("express"), cors=require("cors");
const app=express(); app.use(cors()); app.use(express.json({limit:"1mb"}));
app.get("/health",(req,res)=>res.json({ok:true,version:"6.0.0"}));
app.post("/api/generate",(req,res)=>{
  const {idea,type}=req.body||{};
  if(!idea) return res.status(400).json({error:"idea_required"});
  // Production: call your chosen AI provider here using process.env.AI_API_KEY.
  // Never ship the secret key inside the Android APK.
  res.json({project:{idea,type},features:[
    "تسجيل دخول وحسابات","واجهة رئيسية","بحث وتصنيفات","إدارة المحتوى",
    "إشعارات","إعدادات المستخدم","لوحة تحكم","قاعدة بيانات","واجهة API","اختبارات أولية"
  ]});
});
const port=process.env.PORT||8080; app.listen(port,()=>console.log("AI Builder backend listening on "+port));
